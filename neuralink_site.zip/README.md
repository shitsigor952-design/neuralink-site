NeuraLink Solutions — Static site prototype

How to run locally:

1. Install dependencies:
   npm install

2. Run dev server:
   npm run dev

3. Build:
   npm run build

This is a minimal Vite + React + Tailwind project. Replace /src/App.jsx with your custom code if needed.
