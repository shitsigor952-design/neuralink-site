import React from "react";

export default function App() {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-800">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-500 rounded flex items-center justify-center text-white font-bold">N</div>
            <span className="font-semibold text-lg">NeuraLink Solutions</span>
          </div>
          <nav className="flex gap-6 text-sm">
            <a href="#features" className="hover:text-indigo-600">Fonctionnalités</a>
            <a href="#pricing" className="hover:text-indigo-600">Tarifs</a>
            <a href="#testimonials" className="hover:text-indigo-600">Avis</a>
            <a href="#contact" className="hover:text-indigo-600">Contact</a>
          </nav>
          <a href="#" className="ml-6 px-4 py-2 bg-indigo-600 text-white rounded hover:opacity-90">Essai gratuit</a>
        </div>
      </header>

      {/* Hero */}
      <section className="max-w-7xl mx-auto px-6 py-20 text-center">
        <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
          Ваш копилот ИИ для МСП
        </h1>
        <p className="mt-6 text-lg text-slate-600 max-w-2xl mx-auto">
          Автоматизируйте задачи, генерируйте контент и экономьте время с помощью доступного и персонализированного искусственного интеллекта.
        </p>
        <div className="mt-8 flex justify-center gap-4">
          <a href="#pricing" className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:opacity-90">Узнать тарифы</a>
          <a href="#features" className="px-6 py-3 border rounded-lg hover:bg-slate-100">Подробнее</a>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="bg-white py-20">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-12">Ключевые возможности</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Feature icon="💬" title="Чат-бот ИИ" text="Ассистент, обученный на ваших документах, который моментально отвечает клиентам и сотрудникам." />
            <Feature icon="✍️" title="Генератор контента" text="Пишите письма, посты LinkedIn и коммерческие предложения одним кликом." />
            <Feature icon="📑" title="Анализ счетов" text="Автоматическое извлечение сумм, поставщиков и дат из ваших счетов." />
            <Feature icon="📊" title="Панель управления" text="Отслеживайте KPI и визуализируйте эффект автоматизации в реальном времени." />
            <Feature icon="🔗" title="Интеграции" text="Подключайте платформу к вашему CRM, ERP или почте без сложностей." />
            <Feature icon="🔒" title="Безопасность (GDPR)" text="Ваши данные остаются приватными, хранятся и защищены в Европе." />
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-20">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold mb-12">Наши предложения</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <PriceCard title="Basic" price="49€/мес" features={["1 пользователь", "Базовый чат-бот", "Поддержка по email"]} />
            <PriceCard title="Pro" price="149€/мес" features={["До 10 пользователей", "Продвинутый чат-бот + контент", "Приоритетная поддержка"]} highlight />
            <PriceCard title="Enterprise" price="По запросу" features={["Неограниченные пользователи", "Персонализированный ИИ", "Обучение и интеграция"]} />
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="bg-white py-20">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-12">Отзывы клиентов</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Testimonial text="NeuraLink сократил время обработки счетов на 30%." author="София, бухгалтер" />
            <Testimonial text="Наша маркетинговая команда создает в 5 раз больше контента!" author="Марк, директор по маркетингу" />
            <Testimonial text="Настоящий копилот: отвечает клиентам и интегрирует данные в CRM." author="Клэр, CEO стартапа" />
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="py-20">
        <div className="max-w-3xl mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold mb-6">Свяжитесь с нами</h2>
          <p className="text-slate-600 mb-6">Вопросы? Нужна персональная демонстрация? Напишите нам — команда ответит быстро.</p>
          <form className="grid gap-4 text-left">
            <input type="text" placeholder="Имя" className="border rounded px-4 py-2" />
            <input type="email" placeholder="Email" className="border rounded px-4 py-2" />
            <textarea placeholder="Ваше сообщение" className="border rounded px-4 py-2 min-h-[120px]"></textarea>
            <button className="px-6 py-3 bg-indigo-600 text-white rounded hover:opacity-90">Отправить</button>
          </form>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 text-sm py-8 mt-12">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-4">
          <span>© {new Date().getFullYear()} NeuraLink Solutions — Все права защищены.</span>
          <div className="flex gap-4">
            <a href="#" className="hover:text-white">Правовая информация</a>
            <a href="#" className="hover:text-white">Конфиденциальность</a>
          </div>
        </div>
      </footer>
    </div>
  );
}

function Feature({ icon, title, text }) {
  return (
    <div className="p-6 rounded-lg shadow-sm border bg-slate-50">
      <div className="text-3xl mb-3">{icon}</div>
      <h3 className="font-semibold text-lg mb-2">{title}</h3>
      <p className="text-slate-600 text-sm">{text}</p>
    </div>
  );
}

function PriceCard({ title, price, features, highlight }) {
  return (
    <div className={`p-6 rounded-lg border shadow-sm ${highlight ? 'bg-indigo-50 border-indigo-300 scale-105' : 'bg-white'}`}>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <div className="text-3xl font-bold mb-4">{price}</div>
      <ul className="space-y-2 text-sm text-slate-600 mb-6">
        {features.map((f, i) => <li key={i}>• {f}</li>)}
      </ul>
      <button className={`w-full px-4 py-2 rounded ${highlight ? 'bg-indigo-600 text-white hover:opacity-90' : 'border hover:bg-slate-100'}`}>Выбрать</button>
    </div>
  );
}

function Testimonial({ text, author }) {
  return (
    <div className="p-6 rounded-lg border shadow-sm bg-slate-50">
      <p className="italic mb-4">“{text}”</p>
      <div className="text-sm font-semibold">{author}</div>
    </div>
  );
}
